#Catastrophic forgetting toy example helper utils
#Source: https://deeplearning.neuromatch.io/tutorials/W3D4_ContinualLearning/student/W3D4_Tutorial1.html#elastic-weight-consolidation-ewc

import numpy as np
import matplotlib.pyplot as plt



def plot_mnist(data, nPlots=10):
  """
  Plot MNIST-like data

  Args:
    data: torch.tensor
      MNIST like data to be plotted
    nPlots: int
      Number of samples to be plotted aka Number of plots

  Returns:
    Nothing
  """
  plt.figure(figsize=(12, 8))
  for ii in range(nPlots):
    plt.subplot(1, nPlots, ii + 1)
    plt.imshow(data[ii, 0], cmap="gray")
    plt.axis('off')
  plt.tight_layout
  plt.show()


def multi_task_barplot(accs, tasks, t=None):
  """
  Plot accuracy of multiple tasks

  Args:
    accs: list
      List of accuracies per task
    tasks: list
      List of tasks

  Returns:
    Nothing
  """
  nTasks = len(accs)
  plt.bar(range(nTasks), accs, color='k')
  plt.ylabel('Testing Accuracy (%)', size=18)
  plt.xticks(range(nTasks),
            [f"{TN}\nTask {ii + 1}" for ii, TN in enumerate(tasks.keys())],
            size=18)
  plt.title(t)
  plt.show()


def plot_task(data, samples_num):
  """
  Plots task accuracy

  Args:
    data: torch.tensor
      Data of task to be plotted
    samples_num: int
      Number of samples corresponding to data for task

  Returns:
    Nothing
  """
  plt.plot(figsize=(12, 6))
  for ii in range(samples_num):
    plt.subplot(1, samples_num, ii + 1)
    plt.imshow(data[ii][0], cmap="gray")
    plt.axis('off')
  plt.show()

# @title Helper functions

def load_mnist(mnist_train, mnist_test, verbose=False, asnumpy=True):
  """
  Helper function to load MNIST data
  Note: You can try an alternate implementation with torchloaders

  Args:
    mnist_train: np.ndarray
      MNIST training data
    mnist_test: np.ndarray
      MNIST test data
    verbose: boolean
      If True, print statistics
    asnumpy: boolean
      If true, MNIST data is passed as np.ndarray

  Returns:
   X_test: np.ndarray
      Test data
    y_test: np.ndarray
      Labels corresponding to above mentioned test data
    X_train: np.ndarray
      Train data
    y_train: np.ndarray
      Labels corresponding to above mentioned train data
  """

  x_traint, t_traint = mnist_train.data, mnist_train.targets
  x_testt, t_testt = mnist_test.data, mnist_test.targets

  if asnumpy:
    # Fix dimensions and convert back to np array for code compatability
    # We aren't using torch dataloaders for ease of use
    x_traint = torch.unsqueeze(x_traint, 1)
    x_testt = torch.unsqueeze(x_testt, 1)
    x_train, x_test = x_traint.numpy().copy(), x_testt.numpy()
    t_train, t_test = t_traint.numpy().copy(), t_testt.numpy()
  else:
    x_train, t_train = x_traint, t_traint
    x_test, t_test = x_testt, t_testt

  if verbose:
    print(f"x_train dim: {x_train.shape} and type: {x_train.dtype}")
    print(f"t_train dim: {t_train.shape} and type: {t_train.dtype}")
    print(f"x_train dim: {x_test.shape} and type: {x_test.dtype}")
    print(f"t_train dim: {t_test.shape} and type: {t_test.dtype}")

  return x_train, t_train, x_test, t_test


def permute_mnist(mnist, seed, verbose=False):
    """
    Given the training set, permute pixels of each
    image.

    Args:
      mnist: np.ndarray
        MNIST Data to be permuted
      seed: int
        Set seed for reproducibility
      verbose: boolean
        If True, print statistics

    Returns:
      perm_mnist: List
        Permutated set of pixels for each incoming image
    """

    np.random.seed(seed)
    if verbose: print("Starting permutation...")
    h = w = 28
    perm_inds = list(range(h*w))
    np.random.shuffle(perm_inds)
    perm_mnist = []
    for set in mnist:
        num_img = set.shape[0]
        flat_set = set.reshape(num_img, w * h)
        perm_mnist.append(flat_set[:, perm_inds].reshape(num_img, 1, w, h))
    if verbose: print("done.")
    return perm_mnist

# @title Set random seed

# @markdown Executing `set_seed(seed=seed)` you are setting the seed

# for DL its critical to set the random seed so that students can have a
# baseline to compare their results to expected results.
# Read more here: https://pytorch.org/docs/stable/notes/randomness.html

# Call `set_seed` function in the exercises to ensure reproducibility.
import random
import torch

def set_seed(seed=None, seed_torch=True):
  """
  Function that controls randomness. NumPy and random modules must be imported.

  Args:
    seed : Integer
      A non-negative integer that defines the random state. Default is `None`.
    seed_torch : Boolean
      If `True` sets the random seed for pytorch tensors, so pytorch module
      must be imported. Default is `True`.

  Returns:
    Nothing.
  """
  if seed is None:
    seed = np.random.choice(2 ** 32)
  random.seed(seed)
  np.random.seed(seed)
  if seed_torch:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

  print(f'Random seed {seed} has been set.')


# In case that `DataLoader` is used
def seed_worker(worker_id):
  """
  DataLoader will reseed workers following randomness in
  multi-process data loading algorithm.

  Args:
    worker_id: integer
      ID of subprocess to seed. 0 means that
      the data will be loaded in the main process
      Refer: https://pytorch.org/docs/stable/data.html#data-loading-randomness for more details

  Returns:
    Nothing
  """
  worker_seed = torch.initial_seed() % 2**32
  np.random.seed(worker_seed)
  random.seed(worker_seed)

# @title Set device (GPU or CPU). Execute `set_device()`
# especially if torch modules used.

# Inform the user if the notebook uses GPU or CPU.

def set_device():
  """
  Set the device. CUDA if available, CPU otherwise

  Args:
    None

  Returns:
    Nothing
  """
  device = "cuda" if torch.cuda.is_available() else "cpu"
  if device != "cuda":
    print("GPU is not enabled in this notebook. \n"
          "If you want to enable it, in the menu under `Runtime` -> \n"
          "`Hardware accelerator.` and select `GPU` from the dropdown menu")
  else:
    print("GPU is enabled in this notebook. \n"
          "If you want to disable it, in the menu under `Runtime` -> \n"
          "`Hardware accelerator.` and select `None` from the dropdown menu")

  return device